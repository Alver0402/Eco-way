@echo off
chcp 65001 >nul
title Eco-way - MySQL + API

echo ========================================
echo   Eco-way - Configuracion e inicio
echo ========================================
echo.
echo IMPORTANTE: Antes de continuar, abre XAMPP
echo y pulsa "Start" en MySQL.
echo.
pause

cd /d "%~dp0"

if not exist "node_modules\" (
  echo Instalando dependencias...
  call npm install
)

echo.
echo Configurando base de datos MySQL...
call npm run setup
if errorlevel 1 (
  echo.
  echo Setup fallo. Verifica que MySQL este activo en XAMPP.
  pause
  exit /b 1
)

echo.
echo Iniciando servidor en http://localhost:4000
echo.
call npm run dev
