-- Eco-way — esquema MySQL (phpMyAdmin, setup-mysql.js o Docker init)
-- La base `ecoway` debe existir antes (XAMPP: crear en phpMyAdmin; setup-mysql.js la crea sola).

USE ecoway;

CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) NOT NULL,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  passwordHash VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_streaks (
  userId VARCHAR(36) NOT NULL,
  currentStreak INT NOT NULL DEFAULT 0,
  bestStreak INT NOT NULL DEFAULT 0,
  lastActivityDate DATETIME NULL,
  streakStartDate DATETIME NULL,
  updatedAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (userId),
  CONSTRAINT fk_streaks_user FOREIGN KEY (userId) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_activity_days (
  userId VARCHAR(36) NOT NULL,
  activityDate DATE NOT NULL,
  createdAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (userId, activityDate),
  CONSTRAINT fk_activity_user FOREIGN KEY (userId) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
